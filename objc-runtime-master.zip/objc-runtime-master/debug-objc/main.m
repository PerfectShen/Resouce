
//  main.m
//  debug-objc
//
//  Created by closure on 2/24/16.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
//        NSLog(@"Hello, World!");
        
        NSObject *obj = [[NSObject alloc] init];
        NSLog(@"%@",[obj description]);
    }
    return 0;
}
