//
//  ZHPhotoAssetModel.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoAssetModel.h"

@interface ZHPhotoAssetModel()

@property (nonatomic, assign) BOOL isGif; //是不是gif图片
@property (nonatomic, strong) PHAsset *asset; //图片资源信息
@property (nonatomic, copy) NSString *fileName;

@end

@implementation ZHPhotoAssetModel

- (instancetype)initWithAsset:(PHAsset *)asset {
    if (self = [self init]) {
        self.asset = asset;
        [self _initlizedVars];
    }
    return self;
}

- (void)_initlizedVars {
    self.isGif = NO;
    NSString *fileName = [self.asset valueForKey:@"filename"];
    self.fileName = fileName;
    if ([[fileName lowercaseString] hasSuffix:@".gif"]) {
        self.isGif = YES;
    }
}

@end
