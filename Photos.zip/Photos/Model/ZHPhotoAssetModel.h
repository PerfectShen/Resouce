//
//  ZHPhotoAssetModel.h
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>

@interface ZHPhotoAssetModel : NSObject

@property (nonatomic, assign, readonly) BOOL isGif; //是不是gif图片
@property (nonatomic, strong, readonly) PHAsset *asset; //图片资源信息
@property (nonatomic, copy, readonly) NSString *fileName;
@property (nonatomic, strong) UIImage *image;

/**
 通过相册照片实体初始化 Model

 @param asset asset PHAsset
 @return self
 */
- (instancetype)initWithAsset:(PHAsset *)asset;

@end
