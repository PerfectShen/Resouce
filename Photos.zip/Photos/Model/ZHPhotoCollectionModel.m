//
//  ZHPhotoCollectionModel.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoCollectionModel.h"

@interface ZHPhotoCollectionModel()

@property (nonatomic, strong) PHAssetCollection *assetCollection;

@property (nonatomic, copy) NSString *collectionName; //相册名字
@property (nonatomic, assign) NSInteger imageCount; //图片数量
@property (nonatomic, assign) BOOL hidden; //是否隐藏 默认 NO
@property (nonatomic, strong) UIImage *coverImage; //封面图片
@property (nonatomic, strong) PHFetchResult *assets;



@end

@implementation ZHPhotoCollectionModel

- (instancetype)initWithAssetCollection:(PHAssetCollection *)assetCollection {
    if(self = [self init]) {
        self.hidden = NO;
        self.assetCollection = assetCollection;
        [self _initlizedVars];
    }
    return self;
}

#pragma mark - Private Methods
- (void)_initlizedVars {
    //名字
    PHAssetCollectionType type = self.assetCollection.assetCollectionType;
    if (type == PHAssetCollectionTypeAlbum) {
        self.collectionName = self.assetCollection.localizedTitle;
    }else {
        PHAssetCollectionSubtype subtype = self.assetCollection.assetCollectionSubtype;
        if (subtype == PHAssetCollectionSubtypeSmartAlbumUserLibrary) {
            self.collectionName = @"相机胶卷";
        }else if (subtype == PHAssetCollectionSubtypeSmartAlbumPanoramas) {
            self.collectionName = @"全景照片";
        }else if (subtype == PHAssetCollectionSubtypeSmartAlbumBursts) {
            self.collectionName = @"连拍快照";
        }else if (subtype == PHAssetCollectionSubtypeSmartAlbumFavorites) {
            self.collectionName = @"个人收藏";
        }else if (subtype == PHAssetCollectionSubtypeSmartAlbumRecentlyAdded) {
            self.collectionName = @"最近添加";
        }else if (ZH_IOS_VERSION_9_OR_LATER && subtype == PHAssetCollectionSubtypeSmartAlbumSelfPortraits){
            self.collectionName = @"自拍";
        }else if (ZH_IOS_VERSION_9_OR_LATER && subtype == PHAssetCollectionSubtypeSmartAlbumScreenshots){
            self.collectionName = @"屏幕快照";
        }else {
            self.hidden = YES;
        }
    }

    if(!self.hidden) {
        PHFetchOptions *options = [[PHFetchOptions alloc] init];
        options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:YES]];
        PHFetchResult *resultAssets =  [PHAsset fetchAssetsInAssetCollection:self.assetCollection options:options];
        self.assets = resultAssets;
        self.imageCount = [resultAssets countOfAssetsWithMediaType:PHAssetMediaTypeImage];
        if (self.imageCount > 0) {
            PHAsset *firstAsset = [resultAssets lastObject];
            PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
            requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeOpportunistic;
            requestOptions.synchronous = YES;
            [[PHImageManager defaultManager] requestImageForAsset:firstAsset targetSize:[UIScreen mainScreen].bounds.size contentMode:PHImageContentModeAspectFit options:requestOptions resultHandler:^(UIImage *result, NSDictionary *info) {
                if (result) {
                    self.coverImage = result;
                }
            }];
        }else {
            self.hidden = YES;
        }
      
    }

}

@end
