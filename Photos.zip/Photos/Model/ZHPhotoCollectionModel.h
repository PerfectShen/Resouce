//
//  ZHPhotoCollectionModel.h
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>
#import "ZHPhotoAssetModel.h"

@interface ZHPhotoCollectionModel : NSObject

@property (nonatomic, strong, readonly) PHAssetCollection *assetCollection; // 对应的系统的相册实体
@property (nonatomic, copy, readonly) NSString *collectionName; //相册名字
@property (nonatomic, assign, readonly) NSInteger imageCount; //图片数量
@property (nonatomic, assign, readonly) BOOL hidden; //是否隐藏 默认 NO
@property (nonatomic, strong, readonly) UIImage *coverImage; //封面图片
@property (nonatomic, strong, readonly) PHFetchResult *assets;

/**
 通过 系统相册集合初始化 ZHPhotoCollectionModel

 @param assetCollection PHAssetCollection
 @return self
 */
- (instancetype)initWithAssetCollection:(PHAssetCollection *)assetCollection;

@end
