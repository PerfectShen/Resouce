//
//  ZHPhotoCollectionCell.h
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ZHPhotoCollectionModel;

@interface ZHPhotoCollectionCell : UITableViewCell


/**
 视图绑定数据

 @param data ZHPhotoCollectionModel
 */
- (void)bindData:(ZHPhotoCollectionModel *)data;

@end
