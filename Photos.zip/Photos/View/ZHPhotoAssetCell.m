//
//  ZHPhotoAssetCell.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoAssetCell.h"

@interface ZHPhotoAssetCell ()

@property (nonatomic, strong) UIImageView *aImageView;       //!< 相册图片
@property (nonatomic, strong) UIImageView *aGifIconView;     //!< gif标志

@property (nonatomic, strong)  PHImageRequestOptions *requestOptions;
@property (nonatomic, assign) PHImageRequestID requestId;
@property (nonatomic, strong) ZHPhotoAssetModel *model;

@end

@implementation ZHPhotoAssetCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.requestOptions = [[PHImageRequestOptions alloc] init];
        self.requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeOpportunistic;
        self.requestOptions.synchronous = YES;
        [self configUI];
    }
    return self;
}


#pragma mark - Private Methods
- (void)configUI {
    
    self.backgroundColor = [UIColor zh_colorWithHex:@"#CBCBCB"];
    [self.contentView addSubview:self.aImageView];
    [self.contentView addSubview:self.aGifIconView];
    [self.aImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.top.bottom.mas_equalTo(0);
    }];
    [self.aGifIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(39, 39));
        make.right.equalTo(self.contentView.mas_right);
        make.bottom.equalTo(self.contentView.mas_bottom);
    }];
}

#pragma mark - Public Methods
- (void)bindData:(ZHPhotoAssetModel *)data {
    self.model = data;
    if (data.isGif) {
        self.aGifIconView.hidden = NO;
    }else {
        self.aGifIconView.hidden = YES;
    }
    self.requestId = [[PHImageManager defaultManager] requestImageForAsset:data.asset targetSize:CGSizeMake(150, 150) contentMode:PHImageContentModeAspectFit options:self.requestOptions resultHandler:^(UIImage *result, NSDictionary *info) {
        int32_t requestId = [[info objectForKey:PHImageResultRequestIDKey] intValue];
        if (self.requestId == requestId  && result) {
            self.aImageView.image = result;
        }
    }];
}

#pragma mark - getter

- (UIImageView *)aImageView {
    if (!_aImageView) {
        _aImageView= [[UIImageView alloc] init];
        _aImageView.contentMode = UIViewContentModeScaleAspectFill;
        _aImageView.clipsToBounds = YES;
    }
    return _aImageView;
}

- (UIImageView *)aGifIconView {
    if (!_aGifIconView) {
        _aGifIconView = [[UIImageView alloc] init];
        _aGifIconView.image = [UIImage imageNamed:kGallaryCollectionGIFFlagImageName];
    }
    return _aGifIconView;
}
@end
