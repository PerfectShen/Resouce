//
//  ZHPhotoCollectionCell.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoCollectionCell.h"
#import "ZHPhotoCollectionModel.h"

@interface ZHPhotoCollectionCell()

@property (strong, nonatomic) UIImageView *aCoverImageView;
@property (strong, nonatomic) UILabel *aTitleLabel;
@property (strong, nonatomic) UILabel *aNumberLabel;
@property (strong, nonatomic) UIImageView *aBgImageView;                //!< 封面背景

@end


@implementation ZHPhotoCollectionCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self configUI];
    }
    return self;
}

#pragma mark - ConfigUI
- (void)configUI {
    [self.contentView addSubview:self.aBgImageView];
    [self.contentView addSubview:self.aCoverImageView];
    [self.contentView addSubview:self.aTitleLabel];
    [self.contentView addSubview:self.aNumberLabel];
    [self _addConstraints];
}

- (void)_addConstraints {
    [self.aBgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(11);
        make.top.mas_equalTo(8);
        make.size.mas_equalTo(CGSizeMake(69, 69));
    }];
 
    [self.aCoverImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(11);
        make.top.mas_equalTo(8);
        make.size.mas_equalTo(CGSizeMake(66, 66));
    }];
    [self.aTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.aBgImageView.mas_right).offset(11);
        make.right.mas_equalTo(self.contentView).offset(-11);
        make.top.mas_equalTo(25);
    }];
    [self.aNumberLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.aBgImageView.mas_right).offset(11);
        make.right.mas_equalTo(self.contentView).offset(-11);
        make.top.mas_equalTo(self.aTitleLabel.mas_bottom).offset(8);
    }];
    MASAttachKeys(self.aBgImageView,self.aCoverImageView,self.aTitleLabel,self.aNumberLabel);
}


#pragma mark - Public Methods
- (void)bindData:(ZHPhotoCollectionModel *)data {
    self.aCoverImageView.image = data.coverImage;
    self.aTitleLabel.text = data.collectionName;
    self.aNumberLabel.text = [NSString stringWithFormat:@"%zd张",data.imageCount];
}


#pragma mark - getter
- (UIImageView *)aBgImageView {
    if(!_aBgImageView) {
        _aBgImageView = [[UIImageView alloc] init];
        _aBgImageView.image = [UIImage imageNamed:kGallaryBoxBackgroundImageName];
    }
    return _aBgImageView;
}
- (UIImageView *)aCoverImageView {
    if(!_aCoverImageView) {
        _aCoverImageView = [[UIImageView alloc] init];
        _aCoverImageView.contentMode = UIViewContentModeScaleAspectFill;
        _aCoverImageView.clipsToBounds = YES;
    }
    return _aCoverImageView;
}
- (UILabel *)aTitleLabel {
    if (!_aTitleLabel) {
        _aTitleLabel = [[UILabel alloc] init];
        _aTitleLabel.textColor = [UIColor zh_colorWithHex:@"#000000"];
        _aTitleLabel.font = [UIFont systemFontOfSize:14];
    }
    return _aTitleLabel;
}
- (UILabel *)aNumberLabel {
    if (!_aNumberLabel) {
        _aNumberLabel = [[UILabel alloc] init];
        _aNumberLabel.textColor = [UIColor zh_colorWithHex:@"#888888"];
        _aNumberLabel.font = [UIFont systemFontOfSize:11];
    }
    return _aNumberLabel;
}

@end
