//
//  ZHPhotosViewController.h
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHBaseViewController.h"
#import "ZHPhotoProtocol.h"

@interface ZHPhotosViewController : ZHBaseViewController

@property (nonatomic, weak) id<ZHPhotoPickDelegate> pickDelegate;

@end
