//
//  ZHPhotoCollectionViewController.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoCollectionViewController.h"
#import "ZHPhotoAssetModel.h"
#import "ZHPhotoAssetCell.h"
#import "ZHPhotoWatchViewController.h"

static const double ZHItemMargin = 2.5;

@interface ZHPhotoCollectionViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, strong) NSMutableArray<ZHPhotoAssetModel *> *photoAssetArray; //照片数组
@property (nonatomic, strong) UICollectionView *collectionView; //集合视图
@property (assign, nonatomic) BOOL isScrollToBottom;


@end

@implementation ZHPhotoCollectionViewController

- (instancetype)init {
    if (self = [super init]) {
        self.isScrollToBottom = YES;
        self.photoAssetArray = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configUI];
    [self _fetchAssets];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    if (self.isScrollToBottom) {
        self.isScrollToBottom = NO;
        if(self.photoAssetArray.count > 0) {
            [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:(self.photoAssetArray.count - 1) inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
        }
    }
}

#pragma mark - ConfigUI
- (void)configUI {
    if (self.collectionModel) {
        [self.navigationBar setTitle:self.collectionModel.collectionName];
    }else {
        [self.navigationBar setTitle:@"相机胶卷"];
    }
    [self zh_setupRightButtonWithTitle:NSInternational(kInternationalGeneralAlertCancel) selector:@selector(zh_backAction:)];
    [self zh_setupBackButton];
    [self.view addSubview:self.collectionView];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ZH_NAVIGATIONBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(ZH_SCREEN_WIDTH,ZH_SCREEN_HEIGHT - ZH_NAVIGATIONBAR_HEIGHT - ZH_BOTTOMSPACEAREA_HEIGHT));
        make.leading.trailing.mas_equalTo(0);
    }];
}

#pragma mark - Private Methods
- (void)_fetchAssets {
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        if (!self.collectionModel) { //先构造一个
            PHFetchResult *resultSystem = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum  subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil];
            [resultSystem enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PHAssetCollection *collect = (PHAssetCollection *)obj;
                self.collectionModel = [[ZHPhotoCollectionModel alloc] initWithAssetCollection:collect];
            }];
        }
    
        [self.collectionModel.assets enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            PHAsset *assset = (PHAsset *)obj;
            ZHPhotoAssetModel *model = [[ZHPhotoAssetModel alloc] initWithAsset:assset];
            [self.photoAssetArray addObject:model];
        }];
//        dispatch_async(dispatch_get_main_queue(), ^{
            [self.collectionView reloadData];
//        });
//    });
}


#pragma mark - Action
- (void)zh_backAction:(UIButton *)button {
    if (button) {
        button.userInteractionEnabled = NO;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark  - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.photoAssetArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ZHPhotoAssetCell *cell = [collectionView
                                     dequeueReusableCellWithReuseIdentifier:@"cell"
                                     forIndexPath:indexPath];
    ZHPhotoAssetModel *model = [self.photoAssetArray objectAtIndex:indexPath.item];
    [cell bindData:model];
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat itemH = (ZH_SCREEN_WIDTH - ZHItemMargin * 2) / 3;
    return CGSizeMake(itemH, itemH);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(ZHItemMargin, 0, ZHItemMargin, 0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return ZHItemMargin;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return ZHItemMargin;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    ZHPhotoAssetModel *model = [self.photoAssetArray objectAtIndex:indexPath.item];
    ZHPhotoWatchViewController *vc = [[ZHPhotoWatchViewController alloc] init];
    vc.asset = model.asset;
    vc.fileName = model.fileName;
    vc.pickDelegate = self.pickDelegate;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - getter
-  (UICollectionView *)collectionView {
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[[UICollectionViewFlowLayout alloc] init]];
        _collectionView.backgroundColor = [UIColor zh_colorWithHex:@"#F8F7F5"];
        
        [_collectionView registerClass:[ZHPhotoAssetCell class] forCellWithReuseIdentifier:@"cell"];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
    }
    return _collectionView;
}


@end
