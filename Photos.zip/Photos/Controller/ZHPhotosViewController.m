//
//  ZHPhotosViewController.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotosViewController.h"
#import "ZHPhotoCollectionModel.h"
#import "ZHPhotoCollectionCell.h"
#import "ZHPhotoCollectionViewController.h"

static NSString *const PhotoCollectionCellIdentifier = @"photoCollectionCell";

@interface ZHPhotosViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;          //!< 相册显示
@property (nonatomic, strong) NSMutableArray<ZHPhotoCollectionModel *> *photoCollectionArray;  //相册组数组
@property (nonatomic, strong) UILabel *allowTitle;                //!< 权限提示


@end

@implementation ZHPhotosViewController

- (instancetype)init {
    if (self = [super init]) {
        self.photoCollectionArray = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self pushCollectionViewControllerWithModel:nil];
    [self configUI];
    [self _fetchPhotoGroups];
}

#pragma mark - ConfigUI
- (void)configUI {
    [self.navigationBar setTitle:NSInternational(kInternationalGallarySelectedAblum)];
    [self zh_setupRightButtonWithTitle:NSInternational(kInternationalGeneralAlertCancel) selector:@selector(zh_backAction:)];
    [self.view setBackgroundColor:[UIColor zh_colorWithHex:@"EDEDED"]];
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ZH_NAVIGATIONBAR_HEIGHT + 12);
        make.leading.trailing.mas_equalTo(0);
        make.bottom.equalTo(self.view).offset(-ZH_BOTTOMSPACEAREA_HEIGHT);
    }];
}

#pragma mark - Private Methods
- (void)_fetchPhotoGroups {
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusRestricted ||
        status == PHAuthorizationStatusDenied) {
        self.allowTitle = [[UILabel alloc] init];
        [self.allowTitle setText:NSInternational(kInternationalGallaryAllow)];
        [self.view addSubview:self.allowTitle];
        self.allowTitle.lineBreakMode = NSLineBreakByWordWrapping;
        self.allowTitle.textAlignment = NSTextAlignmentCenter;
        self.allowTitle.numberOfLines = 0;
        [self.allowTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(ZH_NAVIGATIONBAR_HEIGHT + 60);
            make.left.mas_equalTo(self.view.mas_left).offset(40);
            make.right.mas_equalTo(self.view.mas_right).offset(-40);
            make.centerX.mas_equalTo(self.view.mas_centerX);
        }];
    } else {
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            PHFetchResult *resultSystem = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum  subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
            [resultSystem enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PHAssetCollection *collect = (PHAssetCollection *)obj;
                
                ZHPhotoCollectionModel *model = [[ZHPhotoCollectionModel alloc] initWithAssetCollection:collect];
                if (!model.hidden) {
                    [self.photoCollectionArray addObject:model];
                }
            }];
            
            PHFetchResult *resultCustom = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
            [resultCustom enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PHAssetCollection *collect = (PHAssetCollection *)obj;
                ZHPhotoCollectionModel *model = [[ZHPhotoCollectionModel alloc] initWithAssetCollection:collect];
                if (!model.hidden) {
                    [self.photoCollectionArray addObject:model];
                }
            }];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        });
    }
}

- (void)pushCollectionViewControllerWithModel:(ZHPhotoCollectionModel *)model {
    ZHPhotoCollectionViewController *vc = [[ZHPhotoCollectionViewController alloc] init];
    vc.collectionModel = model;
    vc.pickDelegate = self.pickDelegate;
    BOOL animated = NO;
    if (model) {
        animated = YES;
    }
    [self.navigationController pushViewController:vc animated:animated];
}

#pragma mark - Action
- (void)zh_backAction:(UIButton *)button {
    if (button) {
        button.userInteractionEnabled = NO;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.photoCollectionArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZHPhotoCollectionModel *model = [self.photoCollectionArray objectAtIndex:indexPath.row];
    ZHPhotoCollectionCell *cell = (ZHPhotoCollectionCell *)[tableView dequeueReusableCellWithIdentifier:PhotoCollectionCellIdentifier];
    [cell bindData:model];
    return cell;
}

#pragma mark - UITableViewDelegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ZHPhotoCollectionModel *model = [self.photoCollectionArray objectAtIndex:indexPath.row];
    [self pushCollectionViewControllerWithModel:model];
}


#pragma mark - getter
//初始化相册表格
- (UITableView *)tableView {
    if (!_tableView) {
        CGRect frame = self.view.bounds;
        _tableView = [[UITableView alloc]initWithFrame:frame style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 83;
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        [_tableView registerClass:[ZHPhotoCollectionCell class] forCellReuseIdentifier:PhotoCollectionCellIdentifier];
    }
    return _tableView;
}


@end
