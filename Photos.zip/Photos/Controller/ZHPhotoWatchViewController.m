//
//  ZHPhotoWatchViewController.m
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHPhotoWatchViewController.h"
#import "ZHAnimationImageView.h"
#import "ZHAnimatedImage.h"
#import "ZHAlertView.h"
#import "ZHImageGIFCoder.h"

//gif图片大小最大为5M
static const NSInteger GFIMaxLength = 5 * 1024 * 1024;

@interface ZHPhotoWatchViewController ()
//目标区域背景区域
@property (nonatomic, strong) UIView *targetBackView;
@property (nonatomic, strong) ZHAnimationImageView *targetView;
@property (nonatomic, strong) NSData *imageData;


@end

@implementation ZHPhotoWatchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configUI];
    [self _fetchImage];
}

#pragma mark - ConfigUI
- (void)configUI {
    
    [self zh_setupRightButtonWithTitle:NSInternational(kInternationalGeneralAlertSure) selector:@selector(zh_sureButtonAction:)];
    [self zh_setupBackButton];
    self.navigationBar.backgroundColor = [UIColor zh_colorWithHex:@"#303030" alpha:0.75];
    self.view.backgroundColor = [UIColor zh_colorWithHex:@"#000000"];
    [self.view addSubview:self.targetBackView];
    [self.targetBackView addSubview:self.targetView];
    [self _addConstraints];
}
- (void)_addConstraints {
    [self.targetBackView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view.mas_centerX);
        make.centerY.equalTo(self.view.mas_centerY).offset(-ZH_NAVIGATIONBAR_HEIGHT/2);
        make.size.mas_equalTo(CGSizeMake(320, 320));
    }];
    [self.targetView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.equalTo(self.targetBackView).offset(6);
        make.right.bottom.equalTo(self.targetBackView).offset(-6);
    }];
}

- (void)_fetchImage {
    PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
    requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeOpportunistic;
    requestOptions.synchronous = YES;
    if([[self.fileName lowercaseString] hasSuffix:@".gif"]) {
        [[PHImageManager defaultManager] requestImageDataForAsset:self.asset options:requestOptions resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
            NSLog(@"%@",info);
            self.imageData = imageData;
        }];
        ZHAnimatedImage *animatedImage = [[ZHAnimatedImage alloc] initWithAnimatedGIFData:self.imageData];
        self.targetView.animatedImage = animatedImage;
    }else {
        
        [[PHImageManager defaultManager] requestImageForAsset:self.asset targetSize:CGSizeMake(600, 600) contentMode:PHImageContentModeAspectFit options:requestOptions resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
            self.targetView.image = result;
            self.imageData = UIImageJPEGRepresentation(result, 0.9);
        }];
    }
}


#pragma mark - Action
- (void)zh_sureButtonAction:(UIButton *)sender {
    if (sender) {
        sender.userInteractionEnabled = NO;
    }
    
    if([[self.fileName lowercaseString] hasSuffix:@".gif"]) {
        sender.userInteractionEnabled = YES;
        UIImage *gifImage = [ZHImageGIFCoder decodedImageWithData:self.imageData];
        double imageRate = gifImage.size.width * gifImage.size.height * gifImage.images.count/(gifImage.duration * 1000);
        if(imageRate > 5000 || self.imageData.length > GFIMaxLength) {
            [[ZHAlertView alertViewWithTitle:NSInternational(kInternationalGallarySelectGifSizeLimit) message:nil sureBlock:nil] show];
            return ;
        }
    }
    if (self.pickDelegate && [self.pickDelegate respondsToSelector:@selector(photoPickImageData:fileName:)]) {
        [self.pickDelegate photoPickImageData:self.imageData fileName:self.fileName];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
           



#pragma mark - getter
- (UIView *)targetBackView {
    if (!_targetBackView) {
        _targetBackView = [[UIView alloc] init];
        _targetBackView.layer.borderWidth = 4;
        _targetBackView.layer.borderColor = [UIColor zh_colorWithHex:@"#4f4f4f"].CGColor;
        _targetBackView.backgroundColor = [UIColor zh_colorWithHex:@"#292929"];
    }
    return _targetBackView;
}

- (ZHAnimationImageView *)targetView {
    if (!_targetView) {
        _targetView = [[ZHAnimationImageView alloc] init];
        _targetView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _targetView;
}

@end
