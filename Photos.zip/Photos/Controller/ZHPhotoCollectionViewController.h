//
//  ZHPhotoCollectionViewController.h
//  OAIM
//
//  Created by kat on 2018/1/9.
//  Copyright © 2018年 招商银行总行信息技术部. All rights reserved.
//

#import "ZHBaseViewController.h"
#import "ZHPhotoCollectionModel.h"
#import "ZHPhotoProtocol.h"

@interface ZHPhotoCollectionViewController : ZHBaseViewController

//相册集合 model
@property (nonatomic, strong) ZHPhotoCollectionModel *collectionModel;
@property (nonatomic, weak) id<ZHPhotoPickDelegate> pickDelegate;


@end
